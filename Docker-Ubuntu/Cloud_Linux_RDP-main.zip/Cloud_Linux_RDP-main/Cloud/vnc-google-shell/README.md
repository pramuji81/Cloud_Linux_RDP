# vnc-google-shell CHROME DESKTOP

  1. https://console.cloud.google.com/home/dashboard
  
  2. https://cloud.google.com/architecture/chrome-desktop-remote-on-compute-engine?hl=en_US&_ga=2.54915049.-316264778.1626084193
  
  3. wget https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb

  4. git clone https://github.com/alexdanca341341/vnc-google-shell.git
     
     1. cd vnc-google-shell 
     2. cp vnc.py ../
     3. cd

  5. python vnc.py

  6. https://remotedesktop.google.com/headless

  7. click begin , click before , click authorize
  
  8. copy "Debian Linux" and paste on terminal/shell google console

  9. https://remotedesktop.google.com/access








 github

https://github.com/alexdanca341341/vnc-google-shell


console restart / reset:

1. python vnc.py
2.https://remotedesktop.google.com/headless 3. click begin , click before , click authorize
4. copy "Debian Linux" and paste on terminal/shell google console
5. https://remotedesktop.google.com/access

